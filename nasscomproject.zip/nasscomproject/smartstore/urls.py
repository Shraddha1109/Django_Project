from django.urls import path
from . import views

urlpatterns=[
   path('',views.index,name='index'),
   path('home',views.home,name='home'),
   path('product',views.product,name='product'),
   path('page1',views.page1,name='page1'),
   path('page2',views.page2,name='page2'),
   path('gallery',views.gallery,name='gallery'),
   path('page3_template_tag1',views.page3_template_tag1,name='page3_template_tag1')]