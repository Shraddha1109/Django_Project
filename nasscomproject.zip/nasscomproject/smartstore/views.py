from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django import template
# Create your views here.


def index(request):
	template=loader.get_template('index.html')
	return HttpResponse(template.render())
	#return HttpResponse("<h1 style='color:navy'>Welcome to my smartstore</h1>")

def home(request):
	t=template.Template("Welcome to {{post_title}}")
	c=template.Context({'post_title':'Nasscom Training'})
	html=t.render(c)
	return HttpResponse(html)

def product(request):
	template = loader.get_template('product.html')
	html = template.render({'name':'Iphone 7', 'brand':'Apple', 'price':'47000'})
	return HttpResponse(html) 
def page1(request):
	#render(request,template,data)
	data={}
	data['name']='Rajesh'
	data['email']='rajesh@gmail.com'
	response = render(request,'page1.html',data)
	return response

def page2(request):
	#render(request,template,data)
	data={}
	data['skills']=['C','C++','Python','Django','AWS','Dataanalytics','DataScience']
	response = render(request,'page2.html',data)
	return response

def page3_template_tag1(request):
	mydict={'x':20,'y':20,'z':30}
	response=render(request,'page3_template_tag1.html',mydict)
	return response

def gallery(request):
	#prod_dict={'p001':'Iphone7'}	
	prod_dict ={'p001':{'name':'Iphone 7', 'brand':'Apple', 'price':'47000'},'p002':{'name':'Galaxy s10', 'brand':'Samsung', 'price':'40000'}}
	response=render(request,'gallery.html',prod_dict)
	return response