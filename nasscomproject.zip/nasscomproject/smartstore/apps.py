from django.apps import AppConfig


class SmartstoreConfig(AppConfig):
    name = 'smartstore'
