from django.shortcuts import render, redirect
from .models import Product
from .forms import ProductCreate
from django.http import HttpResponse

# Create your views here.
def index(request):
    productdetails = Product.objects.all()
    return render(request,'productdetails.html',{'productdetails':productdetails})

def addproduct(request):
     addproduct = ProductCreate()
     if request.method == 'POST':
         addproduct = ProductCreate(request.POST,request.FILES)
         if addproduct.is_valid():
             addproduct.save()
             return redirect('index')
         else:
             return HttpResponse("Errors occured : Invalid form details, reload again-<a href='{{ url: 'index'}}'>Reload</a>")
     else:
         return render(request,'productadd_form.html',{'add_product':addproduct})