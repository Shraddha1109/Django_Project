from django.apps import AppConfig


class DjangodbappConfig(AppConfig):
    name = 'djangodbapp'
