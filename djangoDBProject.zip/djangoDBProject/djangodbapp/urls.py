
from django.urls import path
from . import views
from djangoDBProject import settings
from django.conf.urls.static import static
from djangoDBProject.settings import DEBUG, STATIC_URL,  MEDIA_URL, MEDIA_ROOT

urlpatterns = [
    path('', views.index, name='index'),
    path('addproduct', views.addproduct, name='addproduct')
]

urlpatterns += static(STATIC_URL, document_root = STATIC_URL)
urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)
