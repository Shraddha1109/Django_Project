from django.apps import AppConfig


class DjangoformappConfig(AppConfig):
    name = 'djangoformapp'
