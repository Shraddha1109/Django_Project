from  django.contrib import admin
from django.urls import path
from .import views

urlpatterns=[
    path('',views.Form1view,name='Form1view')
]