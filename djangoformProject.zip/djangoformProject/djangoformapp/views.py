from django.shortcuts import render

# Create your views here.
def Form1view(request):
    nvalues=len(request.POST)
    data={}
    data['nvalues']=nvalues

    fname = request.POST.get('fname')
    lname = request.POST.get('lname')
    gender = request.POST.get('G')
    email = request.POST.get('email')

    pas = request.POST.get('password')
    mob = request.POST.get('mob')
    city = request.POST.get('city')

    data['fname'] =  fname
    data['lname'] =lname
    data['gender'] = gender
    data['password']=pas
    data['mob'] = mob
    data['email'] = email

    data['city']=city
    response=render(request,'Form1.html',data)
    return response